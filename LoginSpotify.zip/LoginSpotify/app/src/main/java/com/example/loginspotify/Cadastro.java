package com.example.loginspotify;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Cadastro extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);
        Button btLogin = (Button) findViewById(R.id.btLogin);
        btLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView Login = (TextView) findViewById(R.id.Login);
                TextView senha = (TextView) findViewById(R.id.senha);
                String login = Login.getText().toString();
                String Senha = senha.getText().toString();
                if(login.equals("pedro")&&senha.equals("123")){
                    alert("Login realizado com sucesso");
                }else{
                    alert("Login ou senha incorretos");
                }
            }
        });
    }
    private void alert(String s){
        Toast.makeText(this,s,Toast.LENGTH_LONG).show();
    }
}